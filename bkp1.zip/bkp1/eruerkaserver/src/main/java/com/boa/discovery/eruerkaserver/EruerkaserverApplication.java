package com.boa.discovery.eruerkaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EruerkaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(EruerkaserverApplication.class, args);
		
	}

}
