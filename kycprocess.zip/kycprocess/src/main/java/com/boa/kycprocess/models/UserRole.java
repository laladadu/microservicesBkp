package com.boa.kycprocess.models;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

@Entity
public class UserRole {

	@Id
	private String role;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "USERNAME")
	private User user;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
}
